<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dado de alta en FCTNOU</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
    <p><strong><?php echo e($details['username']); ?></strong></p>
    <p><strong><?php echo e($details['password']); ?></strong></p>
    <br>

    <h2><?php echo e($details['salutation']); ?></h2>
</body>
</html><?php /**PATH C:\xampp\htdocs\FCTBACK\resources\views/emails/TestEmail.blade.php ENDPATH**/ ?>